package com.BankApplication;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Operation operlation = new Operation();
		Operation.bankinfo();

	}

}
